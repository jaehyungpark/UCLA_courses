CS 143 Project 1A
By: David Nguyen and Jaehyung Park

This is our submission and we were able to accomplish everything
in the specification.

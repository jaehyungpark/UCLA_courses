CS 111 Lab3b
Jaehyung Park
504212821

Contents of submitted files:

- lab3b-504212821.tar.gz
- Source files: lab3b.py
- Other files: Makefile README.txt

Additional notes:

- Command to run program: python lab3b.py >lab3b_check.txt or make run
- Use make check to run sort and diff from the given solution file (test solution file under solution directory)
- Testing done on lnxsrv09.seas.ucla.edu.

// CS 111 Lab 4 part 2
// Jaehyung Park
// 504212821
//

#include <stdio.h>
#include <unistd.h>
#include <signal.h>
#include <mraa/aio.h>
#include <ctype.h>
#include <fcntl.h>
#include <limits.h>
#include <math.h>
#include <pthread.h>
#include <stdbool.h>
#include <stdlib.h>
#include <time.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <netdb.h>
#include <netinet/in.h>
#include <string.h>

sig_atomic_t volatile run_flag = 1;
sig_atomic_t volatile stop;
sig_atomic_t volatile unit;
sig_atomic_t volatile T;
mraa_aio_context m_aio;
FILE* logfile;
int socket_fd;
bool multi_threads = true;

double get_temperature(uint16_t value, char unit){
	const int B = 4275;
	double R = 1023/(double)value - 1;
	double celsius = 1/(log(R)/B + 1/298.15) - 273.15;
	return unit == 'F' ? celsius * 9.0/5.0 + 32 : celsius;
}

void get_interrupt(int sig){
	if (sig == SIGINT){
		run_flag = 0;
	}
}

void logcmd(FILE* logfile, char command[]){
	fprintf(stderr, "RECV: %s\n", command);
	fprintf(logfile, "%s\n", command);
	fflush(logfile);
}

// setting up the socket was implemented by using the Edison tutorial pdf (6.1 pdf)
// utilizes some code from server.c 
int tcp_connect(int portno){
	// sestup socket
	int socket_fd = socket(AF_INET, SOCK_STREAM, 0);
	if (socket_fd < 0) { 
		perror("ERROR, can't open socket");
		exit(1);
	}
	struct hostent* server = gethostbyname("r01.cs.ucla.edu");
	// if server is not responding, exit
	if (server == NULL){
		fprintf(stderr, "gethostbyname() error\n");
		exit(0);
	}
	struct sockaddr_in serv_addr;
	memset(&serv_addr, 0, sizeof(serv_addr));
	serv_addr.sin_family = AF_INET;
	memcpy(&serv_addr.sin_addr.s_addr, server->h_addr, server->h_length);
	serv_addr.sin_port = htons(portno);

	if (connect(socket_fd, (struct sockaddr*)&serv_addr, sizeof(serv_addr)) < 0){
		perror("Error, connection failed");
		exit(1);
	}
	return socket_fd;
}

void* tcp_listener(void* args){
	(void)args;
	// create buffer for commands
	char cmdbuf[1024] = {0};
	while (read(socket_fd, cmdbuf, sizeof(cmdbuf)) > 0 || true){
		bool valid = true;
		if (cmdbuf[0] == '\0'){
			continue;
		}
		else if (strcmp(cmdbuf, "OFF") == 0){
			logcmd(logfile, cmdbuf);
			close(socket_fd);
			fclose(logfile);
			mraa_aio_close(m_aio);
			exit(0);
		}
		else if (strcmp(cmdbuf, "STOP") == 0){
			stop = true;
		}
		else if (strcmp(cmdbuf, "START") == 0){
			stop = false;
		}
		else if (strcmp(cmdbuf, "SCALE=F") == 0){
			unit = 'F';
		}
		else if (strcmp(cmdbuf, "SCALE=C") == 0){
			unit = 'C';
		}
		else if (strncmp(cmdbuf, "FREQ=", 5) == 0){
			int i;
			for (i = 5; cmdbuf[i] != '\0'; i++){
				if (!isdigit(cmdbuf[i])){
					valid = false;
				}
			}
			if(valid){
				int freq = atoi(cmdbuf + 5);
				freq >= 1 && freq <= 3600 ? (T = freq) : (valid = false);
			}
		}
		else {
			valid = false;
		}
		logcmd(logfile, valid ? cmdbuf : strcat(cmdbuf, " I"));
		memset(cmdbuf, 0, sizeof(cmdbuf));
	}
	pthread_exit(NULL);
}

int main(int argc, char **argv){
	int portno;
	while(true){
		socket_fd = tcp_connect(17000);
		// DevID will ber replaced with UIC (504212821)
		dprintf(socket_fd, "Requesting port - 504212821\n");
		fprintf(stderr, "Sending request - 504212821\n");
		read(socket_fd, &portno, sizeof(int));
		fprintf(stderr, "RECV: %d\n", portno);
		close(socket_fd);
		if (portno != -1){
			break;
		}
		fprintf(stderr, "Bad port number. Reconnecting in a few seconds.\n");
		sleep(10);
	}

	m_aio = mraa_aio_init(0);
	logfile = fopen("lab4_2.log", "w");
	socket_fd = tcp_connect(portno);
	fcntl(socket_fd, F_SETFL, O_NONBLOCK);

	stop = false;
	unit = 'F';	// by default in F
	T = 3;	// by default T = 3
	pthread_t thread_tid;
	if (multi_threads){
		if(pthread_create(&thread_tid, NULL, tcp_listener, NULL) != 0){
			fprintf(stderr, "failed to pthread_create\n");
			exit(1);
		}
	}

	int max_iterations = argc == 2 ? atoi(argv[1]) : INT_MAX;
	while (run_flag){
		int i;
		for (i = 0; i < max_iterations; i++){
			if (!multi_threads){
				char cmdbuf[1024] = {0};
				while (read(socket_fd, cmdbuf, sizeof(cmdbuf)) > 0 || stop){
					bool valid = true;
					if (cmdbuf[0] == '\0'){
						continue;
					}
					else if (strcmp(cmdbuf, "OFF") == 0){
						logcmd(logfile, cmdbuf);
						close(socket_fd);
						fclose(logfile);
						mraa_aio_close(m_aio);
						exit(0);
					}
					else if (strcmp(cmdbuf, "STOP") == 0){
						stop = true;
					}
					else if (strcmp(cmdbuf, "START") == 0){
						stop = false;
					}
					else if (strcmp(cmdbuf, "SCALE=F") == 0){
						unit = 'F';
					}
					else if (strcmp(cmdbuf, "SCALE=C") == 0){
						unit = 'C';
					}
					else if (strncmp(cmdbuf, "FREQ=", 5) == 0){
						int j;
						for (j = 5; cmdbuf[j] != '\0'; i++){
							if (!isdigit(cmdbuf[j])){
								valid = false;
							}
						}
						if (valid){
							int freq = atoi(cmdbuf + 5);
							freq >= 1 && freq <= 3600 ? (T = freq) : (valid = false);
						}
					}
					else{
						valid = false;
					}
					logcmd(logfile, valid ? cmdbuf : strcat(cmdbuf, " I"));
					memset(cmdbuf, 0, sizeof(cmdbuf));
				}
			}

			if (!stop){
				char logbuf[1024] = {0};
				char netbuf[1024] = "504212821";

				time_t t = time(NULL);
				struct tm* tm = localtime(&t);
				sprintf(logbuf, "%0d:%02d:%02d", tm->tm_hour, tm->tm_min, tm->tm_sec);

				uint16_t value = mraa_aio_read(m_aio);
				sprintf(logbuf + strlen(logbuf), " %02.1f", get_temperature(value, unit));
				sprintf(netbuf + strlen(netbuf), " TEMP=%02.1f", get_temperature(value, unit));
				sprintf(logbuf + strlen(logbuf), " %c", unit);

				fprintf(stderr, "SEND: %s\t(Log: %s)\n", netbuf, logbuf);
				fprintf(logfile, "%s\n", logbuf);
				dprintf(socket_fd, "%s\n", netbuf);
				fflush(logfile);
				sleep(T);
			}
		}
	}
	close(socket_fd);
	fclose(logfile);
	mraa_aio_close(m_aio);

	return 0;
}
